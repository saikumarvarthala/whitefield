"use strict";
module.exports = function(app) {
  var userList = require("../controllers/user.controller");

  // userList Routes
  app.route("/users/createnew").post(userList.create_new_user);
  app.route("/users/login").post(userList.login_user);
  app.route("/admin/setuserstatus").post(userList.admin_set_user_status);
  app.route("/admin/getallusers").post(userList.admin_get_all_users);
  app.route("/admin/getallagents").post(userList.admin_get_all_agents);
  app
    .route("/admin/getallagentsbycity")
    .post(userList.admin_get_all_agents_by_city);
  app.route("/users/getonboardstatus").post(userList.get_user_onboard_status);
  app.route("/users/setonboardstatus").post(userList.set_user_onboard_status);
  app
    .route("/admin/assignagenttouser")
    .post(userList.admin_assign_agent_to_user);
  app.route("/users/getagentsunderuser").post(userList.get_agents_under_user);
  app.route("/users/getuserdetails").post(userList.get_user_details);
};
