const BearerModule = require("./servicemodules/bearer"),
  bearerfunc = BearerModule.bearerfunc,
  CLIENT_SECRET = BearerModule.ClientSecretKey;

// ============================

function sendDbError(response, error) {
  response.json({
    error: error.message,
    type: error.name,
    success: false
  });
}

// To send missing error of an absent field
function sendMissError(response, myString) {
  response.json({
    error: myString,
    success: false
  });
}

const mongoose = require("mongoose"),
  jwt = require("jsonwebtoken"),
  User = mongoose.model("Users"),
  fs = require("fs"),
  uniqid = require("uniqid");

exports.create_new_user = function(req, res) {
  var fields = [
    "username",
    "password",
    "fullname",
    "userrole",
    "useremail",
    "userphone",
    "city"
  ];
  var missCount = 0;

  for (var i in fields) {
    if (!req.body[fields[i]]) {
      res.json({
        error: "No " + fields[i] + " found",
        success: false
      });
      missCount++;
      break;
    }
  }
  if (missCount == 0) {
    User.findOne(
      {
        username: req.body.username
      },
      function(err, user) {
        if (err) {
          res.json({
            error: err.message,
            type: err.name
          });
        } else {
          if (user) {
            res.json({
              error: "User name already exists",
              success: false
            });
          } else {
            User.findOne(
              {
                useremail: req.body.useremail
              },
              function(err, user2) {
                if (err) {
                  res.json({
                    error: err.message,
                    type: err.name
                  });
                } else {
                  if (user2) {
                    res.json({
                      error: "User email already exists",
                      success: false
                    });
                  } else {
                    req.body.uniqueid = uniqid();
                    var newUser = new User(req.body);
                    newUser.save(function(err, newuser) {
                      if (err) {
                        sendDbError(res, err);
                      } else {
                        res.json({
                          error: false,
                          success: true
                        });
                      }
                    });
                  }
                }
              }
            );
          }
        }
      }
    );
  }
};

exports.login_user = function(req, res) {
  var inputusername = req.body.username;
  var inputpassword = req.body.password;

  if (inputusername == null) {
    res.json({
      error: "Error! Username has not been entered"
    });
  } else if (inputpassword == null) {
    res.json({
      error: "Error! Password has not been entered"
    });
  } else {
    User.findOne({ username: inputusername }, function(err, user) {
      if (err) res.send(err);

      if (user) {
        // test a matching password:
        user.comparePassword(inputpassword, function(err, isMatch) {
          if (err) res.send(err);

          if (!isMatch) {
            res.json({
              error: true,
              access: "Access denied - username and password are incorrect",
              match: isMatch,
              inputusername: inputusername
            });
          }

          if (isMatch) {
            var myToken = jwt.sign(
              { username: inputusername, userrole: user.userrole },
              CLIENT_SECRET
            );

            res.json({
              error: false,
              access: "Access granted - username and password are correct",
              match: isMatch,
              inputusername: inputusername,
              accesstoken: myToken,
              userrole: user.userrole,
              userfullname: user.fullname
            });
          }
        });
      }

      if (!user) {
        res.json({
          error: true,
          errormsg: "ERROR: User does NOT exist!"
        });
      }
    });
  }
};

exports.admin_set_user_status = function(req, res) {
  var myToken = bearerfunc(req);
  if (myToken.userrole != "IB_ADMIN") {
    res.json({
      error: true,
      success: false,
      message: "You do not have the necessary admin privileges."
    });
  } else {
    if (
      !req.body.userstatus ||
      (req.body.userstatus !== "rejected" &&
        req.body.userstatus !== "pending" &&
        req.body.userstatus !== "active" &&
        req.body.userstatus !== "blocked")
    ) {
      res.json({
        error: "Status is missing or isn't valid",
        success: false
      });
    } else if (!req.body.uniqueid) {
      res.json({
        error: "Unique Id of user is missing",
        success: false
      });
    } else {
      User.findOneAndUpdate(
        {
          uniqueid: req.body.uniqueid
        },
        {
          $set: {
            userstatus: req.body.userstatus
          }
        },
        {
          new: true
        },
        function(err, user) {
          if (err) {
            sendDbError(res, err);
          } else {
            res.json({
              success: true,
              error: false,
              message:
                "Changed the status of " +
                user.username +
                " to " +
                user.userstatus
            });
          }
        }
      );
    }
  }
};

exports.admin_get_all_users = function(req, res) {
  var myToken = bearerfunc(req);
  if (myToken.userrole != "IB_ADMIN") {
    res.json({
      error: true,
      success: false,
      message: "You do not have the necessary admin privileges."
    });
  } else {
    User.find({}, function(err, docs) {
      if (err) {
        sendDbError(res, err);
      } else {
        res.json({
          success: true,
          error: false,
          message: "Sent all documents",
          users: docs
        });
      }
    });
  }
};

exports.get_user_onboard_status = function(req, res) {
  var myToken = bearerfunc(req);
  if (myToken.userrole == "IB_USER" || myToken.userrole == "IB_ADMIN") {
    User.findOne({ username: myToken.username }, function(err, user) {
      if (err) {
        sendDbError(res, err);
      } else {
        res.json({
          success: true,
          error: false,
          onboardstatus: user.onboardstatus
        });
      }
    });
  } else {
    res.json({
      error: true,
      success: false,
      message: "Not a user or an admin"
    });
  }
};

exports.set_user_onboard_status = function(req, res) {
  var myToken = bearerfunc(req);
  if (
    !req.body.onboardstatus ||
    !(
      req.body.onboardstatus == "watchvideo" ||
      req.body.onboardstatus == "givetests" ||
      req.body.onboardstatus == "onboarded"
    )
  ) {
    res.json({
      error: true,
      success: false,
      message: "No valid on-board status provided"
    });
  } else if (myToken.userrole == "IB_USER" || myToken.userrole == "IB_ADMIN") {
    User.findOneAndUpdate(
      { username: myToken.username },
      {
        $set: {
          onboardstatus: req.body.onboardstatus
        }
      },
      {
        new: true
      },
      function(err, user) {
        if (err) {
          sendDbError(res, err);
        } else {
          res.json({
            success: true,
            error: false,
            onboardstatus: user.onboardstatus,
            message: "Changed the onboard-status of the user"
          });
        }
      }
    );
  } else {
    res.json({
      error: true,
      success: false,
      message: "Not a user or an admin"
    });
  }
};

exports.create_new_agent = function(req, res) {
  var fields = [
    "username",
    "password",
    "fullname",
    "useremail",
    "userphone",
    "city"
  ];
  var missCount = 0;

  for (var i in fields) {
    if (!req.body[fields[i]]) {
      res.json({
        error: "No " + fields[i] + " found",
        success: false
      });
      missCount++;
      break;
    }
  }
  if (missCount == 0) {
    User.findOne(
      {
        username: req.body.username
      },
      function(err, user) {
        if (err) {
          res.json({
            error: err.message,
            type: err.name
          });
        } else {
          if (user) {
            res.json({
              error: "User name already exists",
              success: false
            });
          } else {
            User.findOne(
              {
                useremail: req.body.useremail
              },
              function(err, user2) {
                if (err) {
                  res.json({
                    error: err.message,
                    type: err.name
                  });
                } else {
                  if (user2) {
                    res.json({
                      error: "User email already exists",
                      success: false
                    });
                  } else {
                    req.body.uniqueid = uniqid();
                    req.body.userrole = "IB_AGENT";
                    var newUser = new User(req.body);
                    newUser.save(function(err, newuser) {
                      if (err) {
                        sendDbError(res, err);
                      } else {
                        res.json({
                          error: false,
                          success: true
                        });
                      }
                    });
                  }
                }
              }
            );
          }
        }
      }
    );
  }
};

exports.admin_get_all_agents = function(req, res) {
  var myToken = bearerfunc(req);
  if (myToken.userrole != "IB_ADMIN") {
    res.json({
      error: true,
      success: false,
      message: "You do not have the necessary admin privileges."
    });
  } else {
    User.find(
      {
        userrole: "IB_AGENT"
      },
      function(err, docs) {
        if (err) {
          sendDbError(res, err);
        } else {
          res.json({
            success: true,
            error: false,
            message: "Sent all documents",
            users: docs
          });
        }
      }
    );
  }
};

exports.admin_get_all_agents_by_city = function(req, res) {
  var myToken = bearerfunc(req);
  if (myToken.userrole != "IB_ADMIN") {
    res.json({
      error: true,
      success: false,
      message: "You do not have the necessary admin privileges."
    });
  } else if (!req.body.city) {
    res.json({
      error: true,
      success: false,
      message: "City not given"
    });
  } else {
    User.find(
      {
        userrole: "IB_AGENT",
        city: req.body.city
      },
      function(err, docs) {
        if (err) {
          sendDbError(res, err);
        } else {
          res.json({
            success: true,
            error: false,
            message: "Sent all documents",
            users: docs
          });
        }
      }
    );
  }
};

exports.admin_assign_agent_to_user = function(req, res) {
  var myToken = bearerfunc(req);
  if (myToken.userrole != "IB_ADMIN") {
    res.json({
      error: true,
      success: false,
      message: "You do not have the necessary admin privileges."
    });
  } else if (!req.body.supername) {
    sendMissError(res, "No super name given");
  } else if (!req.body.agentname) {
    sendMissError(res, "No agent name given");
  } else {
    User.findOne(
      {
        username: req.body.supername
      },
      function(err, doc) {
        if (err) {
          sendDbError(res, err);
        } else {
          if (!doc) {
            res.json({
              success: false,
              error: true,
              message: "No user found"
            });
          } else {
            User.findOne(
              {
                username: req.body.agentname,
                userrole: "IB_AGENT"
              },
              function(err, doc2) {
                if (err) {
                  sendDbError(res, err);
                } else {
                  if (!doc2) {
                    res.json({
                      success: false,
                      error: true,
                      message: "No agent found"
                    });
                  } else {
                    var p = 0;
                    for (var i in doc.assignedAgents) {
                      if (
                        doc.assignedAgents[i].agentName == req.body.agentname
                      ) {
                        p = 1;
                      }
                    }
                    if (p == 1) {
                      res.json({
                        success: false,
                        error: true,
                        message: "Agent already assigned to this user"
                      });
                    } else {
                      User.findOneAndUpdate(
                        {
                          username: req.body.supername
                        },
                        {
                          $push: {
                            assignedAgents: {
                              agentName: doc2.username,
                              addedOn: new Date()
                            }
                          }
                        },
                        {
                          new: true
                        },
                        function(err, compl) {
                          if (err) {
                            sendDbError(res, err);
                          } else {
                            User.findOneAndUpdate(
                              {
                                username: req.body.agentname
                              },
                              {
                                $push: {
                                  assignedTo: {
                                    userName: doc.username,
                                    addedOn: new Date()
                                  }
                                }
                              },
                              {
                                new: true
                              },
                              function(err, compl2) {
                                if (err) {
                                  sendDbError(res, err);
                                } else {
                                  res.json({
                                    success: true,
                                    error: false,
                                    message:
                                      "Agent has been assigned successfully."
                                  });
                                }
                              }
                            );
                          }
                        }
                      );
                    }
                  }
                }
              }
            );
          }
        }
      }
    );
  }
};

exports.get_agents_under_user = function(req, res) {
  var myToken = bearerfunc(req);
  if (myToken.userrole != "IB_ADMIN" && myToken.userrole != "IB_USER") {
    res.json({
      error: true,
      success: false,
      message: "You do not have the necessary admin or super privileges.",
      userrole: myToken.userrole
    });
  } else {
    if (!req.body.username) {
      sendMissError(res, "Username not provided");
    } else {
      User.findOne(
        {
          username: req.body.username
        },
        function(err, user) {
          if (err) {
            sendDbError(res, err);
          } else {
            if (!user) {
              res.json({
                success: false,
                error: true,
                message: "No user exists"
              });
            } else if (user.userrole == "IB_AGENT") {
              res.json({
                success: false,
                error: true,
                message: "The user is agent type - cannot have agents under."
              });
            } else {
              res.json({
                success: true,
                error: false,
                agents: user.assignedAgents
              });
            }
          }
        }
      );
    }
  }
};

exports.get_user_details = function(req, res) {
  var rb = req.body;

  if (!rb.username) {
    sendMissError(res, "Username is not given");
  } else {
    User.findOne(
      {
        username: rb.username
      },
      function(err, user) {
        if (err) {
          sendDbError(res, err);
        } else {
          if (user) {
            res.json({
              success: true,
              error: false,
              userdetails: user
            });
          } else {
            res.json({
              success: false,
              error: true,
              message: "No user found"
            });
          }
        }
      }
    );
  }
};
